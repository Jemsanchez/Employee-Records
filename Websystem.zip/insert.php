<?php  
 $connect = mysqli_connect("localhost", "root", "", "employee_records");  
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = ''; 
      $first_name = mysqli_real_escape_string($connect, $_POST["first_name"]);  
      $last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);  
      $address = mysqli_real_escape_string($connect, $_POST["address"]);  
      $email = mysqli_real_escape_string($connect, $_POST["email"]);  
      $phone_number = mysqli_real_escape_string($connect, $_POST["phone_number"]);
      $date_hired = mysqli_real_escape_string($connect, $_POST["date_hired"]);  
      $contract_sign = mysqli_real_escape_string($connect, $_POST["contract_sign"]);
      $tin_no = mysqli_real_escape_string($connect, $_POST["tin_no"]);
      $weekly_salary = mysqli_real_escape_string($connect, $_POST["weekly_salary"]);
      $team = mysqli_real_escape_string($connect, $_POST["team"]);          
      if($_POST["id"] != '')  
      {  
           $query = "  
           UPDATE employee_records   
           SET first_name='$first_name',   
           last_name='$last_name',   
           address='$address',   
           email = '$email',   
           phone_number = '$phone_number',
           date_hired = '$date_hired',
           contract_sign = '$contract_sign',
           tin_no = '$tin_no',
           weekly_salary = '$weekly_salary',
           team = '$team'
           WHERE id='".$_POST["id"]."'";  
           $message = 'Data Updated';  
      }  
      else  
      {  
           $query = "  
           INSERT INTO employee_records(first_name, last_name, address, email, phone_number, date_hired, contract_sign, tin_no, weekly_salary, team)  
           VALUES('$first_name', '$last_name', '$address', '$email', '$phone_number', '$date_hired', '$contract_sign', '$tin_no', '$weekly_salary', '$team');  
           ";  
           $message = 'Data Inserted';  
      }  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM employee_records ORDER BY id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">Employee first_name</th>  
                          <th width="15%">Edit</th>  
                          <th width="15%">View</th>
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["first_name"] . '</td>  
                          <td><input type="button" name="edit" value="Edit" id="'.$row["id"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                          <td><input type="button" name="view" value="view" id="' . $row["id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }  
      echo $output;  
 }  
 ?>
 