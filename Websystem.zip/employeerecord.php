<?php
	include("connect.php");

	if (isset($_POST['first_name'])) {

		$first_name= $_POST['first_name'] ;
		$last_name= $_POST['last_name'] ;
		$address= $_POST['address'] ;
		$email= $_POST['email'] ;
		$phone_number= $_POST['phone_number'] ;
		$date_hired= $_POST['date_hired'] ;
		$contract_sign= $_POST['contract_sign'] ;
		$tin_no= $_POST['tin_no'] ;
		$weekly_salary= $_POST['weekly_salary'] ;
		$team= $_POST['team'] ;
		$image= $_POST['image'] ;


		if ($first_name != null && $last_name !=null && $address !=null && $email !=null && $phone_number !=null && $date_hired !=null && $contract_sign !=null && $tin_no !=null && $weekly_salary !=null && $team !=null && $image !=null) {
			$q ="INSERT INTO employee_records (first_name , last_name ,address ,email ,phone_number ,date_hired ,contract_sign ,tin_no ,weekly_salary ,team ,image)
				VALUES ('$first_name', '$last_name', '$address' , '$email', '$phone_number', '$date_hired', '$contract_sign', '$tin_no', '$weekly_salary' ,'$team', '$image')
			" ;
			if (@mysql_query($q , $dbc)) {
				echo "Employee successfully Registered";
			} else {
				echo $q;
			}

		}else {
			echo "please fill all the boxes";
		}
	}
?>