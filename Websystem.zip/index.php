<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Index</title>

	<link href="css/style.css" rel="stylesheet">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

</head>
<body>
	<nav style="background-color: #187b32; width: 100%; height: 40px;"></nav>

	<div id="wrapper" style="width: 90%;">
		<div id="header">
			<div id="header_top">
				<div id="logo">
					<img src="employeerecords.png" width="300px" height="70px" style="margin-top: 10px; margin-left:10px;"></img>
				</div>

				<div id="php" style="float: right; margin-top: 70px; margin-right: 10px;">
				<?php
					session_start() ;
					if (isset($_SESSION ['user_name'])) {

					echo $_SESSION ['user_name'] ;
 
					echo '<a href="logout.php">Log out</a>' ;
					} else{
					header("location:login.php") ;
					} 
				?>
				</div>

				<div class="container" style="background-color: #07255a; margin-top: 100px; width: 100%; height: 750px; border-radius: 10px;">
				<nav style="float: left;">
					<h3 style="color: white; margin:20px;">Add New Employee</h3>
					
					<div id="search" style="width: 20%; float: right; margin-top: -50px; margin-right: 20px;">

						<input type="text" class="form-control" placeholder="Search...." name="Search">
						<div class="input-group-btn">
						<button class="btn btn-default" type="submit" style="float:right;margin-top: -34px;">
						<i class="glyphicon glyphicon-search"></i></button>

					</div>
					
					<h4 style="color: white; margin-top: 20px;"> See all records</h4>
					<a href="http://localhost/Websystem/datatables.php">
					<button class="button" style="vertical-align: middle;"> <span>See All</span>
					</button></a>
				

				</nav>

				<nav style="border-radius:20px; background-color: #d7d7d7; border-style: solid; border-width: 2px; border-color: white; width: 50%; height: 560px; margin-top: 120px; margin-left: 50px;">

				<div>
					<div style="color: blue; margin-left: 180px;">
						<?php
						include("connect.php");

							if (isset($_POST['first_name'])) {

							$first_name= $_POST['first_name'] ;
							$last_name= $_POST['last_name'] ;
							$address= $_POST['address'] ;
							$email= $_POST['email'] ;
							$phone_number= $_POST['phone_number'] ;
							$date_hired= $_POST['date_hired'] ;
							$contract_sign= $_POST['contract_sign'] ;
							$tin_no= $_POST['tin_no'] ;
							$weekly_salary= $_POST['weekly_salary'] ;
							$team= $_POST['team'] ;
							$image= $_POST['image'] ;


						if ($first_name != null && $last_name !=null && $address !=null && $email !=null && $phone_number !=null && $date_hired !=null && $contract_sign !=null && $tin_no !=null && $weekly_salary !=null && $team !=null && $image !=null) {
						$q ="INSERT INTO employee_records (first_name , last_name ,address ,email ,phone_number ,date_hired ,contract_sign ,tin_no ,weekly_salary ,team ,image)
							VALUES ('$first_name', '$last_name', '$address' , '$email', '$phone_number', '$date_hired', '$contract_sign', '$tin_no', '$weekly_salary' ,'$team', '$image')
							" ;
						if (@mysql_query($q , $dbc)) {
							echo "Employee Successfully Registered";
						} else {
							echo $q;
						}

						}else {
							echo " <h4> Please fill all the boxes. </h4>";
						}
						}
						?>
					</div>

					<h4 style="text-align: center; color: black;">Fill up form for new Employee</h4>
					<form method="post" action="index.php" style="margin: 30px; color: black;">
						First Name:
						<input type="text" name="first_name" placeholder=" first name" style="width: 400px; height: 20px; float: right;" required><br><br>

						Last Name:
						<input type="text" name="last_name" placeholder=" last name" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Address:
						<input type="text" name="address" placeholder=" Ortigas City" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Email:
						<input type="email" name="email" placeholder=" sample@gmail.com" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Phone Number:
						<input type="text" name="phone_number" placeholder=" 09xxxxxxxxxx" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Date Hired:
						<input type="date" name="date_hired" placeholder=" January 1 2018" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Contract Sign:
						<input type="date" name="contract_sign" placeholder=" January 1 2019" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						TIN No.:
						<input type="text" name="tin_no" placeholder=" 0912456" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Weekly Salary:
						<input type="text" name="weekly_salary" placeholder=" 4000" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						Team/Branch:
						<input type="text" name="team" placeholder=" Metacom" style="width: 400px; height: 20px;float: right;" required=""><br><br>

						2X2 Image:
						<input type="file" name="image" style="margin-left: 130px; margin-top: -20px;" required="" />

						<input type="submit" value="Register" name="Add>>" style="color: black; float: right; border-left-style: solid; border-width: 2px; border-radius: 4px; border-color: green;">

					</form>

				</div>
				</nav>


				</div>

			</div>

		</div>
	</div>

	<div style="margin-top: 80px;">
		<nav style="background-color: #187b32; width: 100%; height: 40px;"></nav>
	</div>

<script src="js/jquery-3.3.1.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


</body>

</html>