<?php

	$dbc = @mysql_connect('localhost','root','');
	@mysql_select_db('employeerecords', $dbc);
?>